# Scene2 side_clear 反馈微步候选

此候选从脚本 SHA256 `0664B0B400C2A6F79C1D23B1857CC8B045A8535EFFBE4B41C16BCBB88FC308D6` 派生，只修改抓取前的 `side_clear` 执行和失败清理。

候选脚本 SHA256：`15A8F2D5B50908A50FB5084CA7F307E9A26B73C063059C343DEAC43D8E607930`。

## 修改范围

- `side_clear` 单段最大活动臂关节变化从通用的 8°收紧为 1.20°；
- 每一微步都重新读取 `/sensors_data_raw` 的真实关节角并计算 FK；
- 每步最大关节跟踪误差 0.50°，最大末端位置误差 8 mm；
- 超限最多反馈重规划两次，仍不到位立即失败；
- 失败时先锁存当前实测关节状态，再交回官方自动摆臂模式；不执行已证明会继续跑偏的大幅开环回退；
- 视觉、抓取点、20°姿态保护、夹爪、下降、闭爪和抓后反向回放均未修改。

## 第一阶段：只跑 10% 往返微步

```bash
python3 -u "$SCRIPT" \
  --restricted-side-execute \
  --restricted-side-fraction 0.10 \
  --move-time 3.0 \
  2>&1 | tee /tmp/scene2_sideclear_feedback_10pct.log
```

通过条件：

- 出现 `restricted side restored`；
- 每个 `joint feedback ... tracking_error` 的绝对值不超过 0.50°；
- 每个 `xyz_err` 不超过 0.008 m；
- 不出现 `joint tracking error`、`tracking error` 或 `IK subdivision exhausted`。

第一阶段未通过时不要运行完整侧移或抓取。

## 第二阶段：完整侧移往返

只在 10% 测试通过后执行：

```bash
python3 -u "$SCRIPT" \
  --restricted-side-execute \
  --restricted-side-fraction 1.00 \
  --move-time 3.0 \
  2>&1 | tee /tmp/scene2_sideclear_feedback_full.log
```

完整抓取命令保持原参数；正式入口会自动使用相同的 side_clear 微步门槛。
